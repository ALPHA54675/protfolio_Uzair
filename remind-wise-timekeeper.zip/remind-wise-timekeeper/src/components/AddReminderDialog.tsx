
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { CalendarIcon, Clock, Volume2 } from 'lucide-react';
import { useReminders, Reminder } from '@/contexts/ReminderContext';
import { scheduleNotification, cancelNotification, getAvailableNotificationSounds } from '@/services/notificationService';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';

interface AddReminderDialogProps {
  open: boolean;
  onClose: () => void;
  reminder?: Reminder | null;
}

const AddReminderDialog: React.FC<AddReminderDialogProps> = ({ open, onClose, reminder }) => {
  const { addReminder, updateReminder } = useReminders();
  const { toast } = useToast();
  const [title, setTitle] = useState('');
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [time, setTime] = useState('');
  const [sounds, setSounds] = useState<{ id: string, name: string }[]>([]);
  const [selectedSound, setSelectedSound] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  
  // Load available notification sounds
  useEffect(() => {
    const loadSounds = async () => {
      const availableSounds = await getAvailableNotificationSounds();
      setSounds(availableSounds);
    };
    
    if (open) {
      loadSounds();
    }
  }, [open]);
  
  // Initialize form with reminder data if editing
  useEffect(() => {
    if (reminder) {
      setTitle(reminder.title);
      const reminderDate = new Date(reminder.datetime);
      setDate(reminderDate);
      setTime(format(reminderDate, 'HH:mm'));
      setSelectedSound(reminder.soundName);
    } else {
      setTitle('');
      setDate(undefined);
      setTime('');
      setSelectedSound(undefined);
    }
  }, [reminder, open]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast({
        variant: "destructive",
        title: "Title required",
        description: "Please enter a reminder title",
      });
      return;
    }
    
    if (!date) {
      toast({
        variant: "destructive",
        title: "Date required",
        description: "Please select a date",
      });
      return;
    }
    
    if (!time) {
      toast({
        variant: "destructive",
        title: "Time required",
        description: "Please select a time",
      });
      return;
    }
    
    try {
      setLoading(true);
      
      // Parse the time string and combine with date
      const [hours, minutes] = time.split(':').map(Number);
      const datetime = new Date(date);
      datetime.setHours(hours, minutes);
      
      if (datetime < new Date()) {
        toast({
          variant: "destructive",
          title: "Invalid time",
          description: "The reminder time must be in the future",
        });
        return;
      }
      
      if (reminder) {
        // Cancel existing notification
        if (reminder.notificationId) {
          await cancelNotification(reminder.notificationId);
        }
        
        // Schedule new notification
        const notificationId = await scheduleNotification({
          ...reminder,
          title,
          datetime: datetime.toISOString(),
          soundName: selectedSound
        });
        
        await updateReminder({
          ...reminder,
          title,
          datetime: datetime.toISOString(),
          notificationId,
          soundName: selectedSound
        });
      } else {
        // Create new reminder with notification
        const reminderData = {
          title,
          datetime: datetime.toISOString(),
          soundName: selectedSound
        };
        
        const newReminder = await addReminder(reminderData);
        
        // Schedule notification
        const notificationId = await scheduleNotification(newReminder);
        
        // Update reminder with notification ID
        if (notificationId) {
          await updateReminder({
            ...newReminder,
            notificationId
          });
        }
      }
      
      onClose();
    } catch (error) {
      console.error('Error saving reminder:', error);
      toast({
        variant: "destructive",
        title: "Failed to save reminder",
        description: "Please try again",
      });
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{reminder ? 'Edit Reminder' : 'New Reminder'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              placeholder="What do you need to remember?"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              autoFocus
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    id="date"
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="time">Time</Label>
              <div className="flex items-center">
                <Input
                  id="time"
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="sound">Notification Sound</Label>
            <Select value={selectedSound} onValueChange={setSelectedSound}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a sound" />
              </SelectTrigger>
              <SelectContent>
                {sounds.map((sound) => (
                  <SelectItem key={sound.id} value={sound.id}>
                    {sound.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex justify-end space-x-2 pt-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={loading}
              className="bg-reminder hover:bg-reminder-dark"
            >
              {loading ? 'Saving...' : reminder ? 'Update' : 'Create'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddReminderDialog;
