
import React from 'react';
import { Button } from '@/components/ui/button';
import { BellRing, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface NavigationProps {
  activeTab: 'reminders' | 'stopwatch';
  setActiveTab: (tab: 'reminders' | 'stopwatch') => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 border-t bg-background flex justify-around py-2 px-4">
      <Button
        variant="ghost"
        className={cn(
          "flex-1 flex flex-col items-center gap-1 h-auto py-2 px-4",
          activeTab === 'reminders' ? 'text-reminder' : 'text-muted-foreground'
        )}
        onClick={() => setActiveTab('reminders')}
      >
        <BellRing className="h-5 w-5" />
        <span className="text-xs">Reminders</span>
      </Button>
      
      <Button
        variant="ghost"
        className={cn(
          "flex-1 flex flex-col items-center gap-1 h-auto py-2 px-4",
          activeTab === 'stopwatch' ? 'text-stopwatch' : 'text-muted-foreground'
        )}
        onClick={() => setActiveTab('stopwatch')}
      >
        <Clock className="h-5 w-5" />
        <span className="text-xs">Stopwatch</span>
      </Button>
    </div>
  );
};

export default Navigation;
