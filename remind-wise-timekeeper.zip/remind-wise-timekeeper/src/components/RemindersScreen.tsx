
import React, { useState, useEffect } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/components/ui/use-toast";
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Mic, Plus, Edit, Trash2 } from 'lucide-react';
import { useReminders, Reminder } from '@/contexts/ReminderContext';
import AddReminderDialog from './AddReminderDialog';
import VoiceInput from './VoiceInput';

const RemindersScreen = () => {
  const { reminders, toggleCompleted, deleteReminder, loading } = useReminders();
  const [isAddReminderOpen, setIsAddReminderOpen] = useState(false);
  const [isVoiceInputOpen, setIsVoiceInputOpen] = useState(false);
  const [reminderToEdit, setReminderToEdit] = useState<Reminder | null>(null);
  const [reminderToDelete, setReminderToDelete] = useState<Reminder | null>(null);
  const { toast } = useToast();

  const handleEditReminder = (reminder: Reminder) => {
    setReminderToEdit(reminder);
    setIsAddReminderOpen(true);
  };

  const handleDeleteReminder = (reminder: Reminder) => {
    setReminderToDelete(reminder);
  };

  const confirmDelete = async () => {
    if (reminderToDelete) {
      await deleteReminder(reminderToDelete.id);
      setReminderToDelete(null);
    }
  };

  const closeAddDialog = () => {
    setIsAddReminderOpen(false);
    setReminderToEdit(null);
  };

  // Get upcoming reminders (not completed)
  const upcomingReminders = reminders
    .filter(reminder => !reminder.completed)
    .sort((a, b) => new Date(a.datetime).getTime() - new Date(b.datetime).getTime());

  // Get completed reminders
  const completedReminders = reminders
    .filter(reminder => reminder.completed)
    .sort((a, b) => new Date(b.datetime).getTime() - new Date(a.datetime).getTime());

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center p-4">
        <h1 className="text-2xl font-bold text-reminder">Reminders</h1>
        <div className="flex gap-2">
          <Button
            onClick={() => setIsVoiceInputOpen(true)}
            variant="outline"
            size="icon"
            className="rounded-full"
          >
            <Mic className="h-4 w-4" />
          </Button>
          <Button
            onClick={() => setIsAddReminderOpen(true)}
            variant="default"
            size="icon"
            className="bg-reminder hover:bg-reminder-dark rounded-full"
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <ScrollArea className="flex-1 p-4">
        {loading ? (
          <div className="flex items-center justify-center h-40">
            <p className="text-muted-foreground">Loading reminders...</p>
          </div>
        ) : upcomingReminders.length === 0 && completedReminders.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-center">
            <p className="text-muted-foreground mb-2">No reminders yet</p>
            <Button 
              variant="outline" 
              onClick={() => setIsAddReminderOpen(true)}
              className="gap-2"
            >
              <Plus className="h-4 w-4" /> Add your first reminder
            </Button>
          </div>
        ) : (
          <>
            {upcomingReminders.length > 0 && (
              <div className="mb-6">
                <h2 className="text-sm font-medium text-muted-foreground mb-2">Upcoming</h2>
                <div className="space-y-3">
                  {upcomingReminders.map(reminder => (
                    <ReminderItem
                      key={reminder.id}
                      reminder={reminder}
                      onToggle={toggleCompleted}
                      onEdit={handleEditReminder}
                      onDelete={handleDeleteReminder}
                    />
                  ))}
                </div>
              </div>
            )}
            
            {completedReminders.length > 0 && (
              <div>
                <h2 className="text-sm font-medium text-muted-foreground mb-2">Completed</h2>
                <div className="space-y-3">
                  {completedReminders.slice(0, 5).map(reminder => (
                    <ReminderItem
                      key={reminder.id}
                      reminder={reminder}
                      onToggle={toggleCompleted}
                      onEdit={handleEditReminder}
                      onDelete={handleDeleteReminder}
                    />
                  ))}
                  {completedReminders.length > 5 && (
                    <Button 
                      variant="ghost" 
                      className="w-full text-xs text-muted-foreground"
                    >
                      View all {completedReminders.length} completed reminders
                    </Button>
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </ScrollArea>
      
      <AddReminderDialog
        open={isAddReminderOpen}
        onClose={closeAddDialog}
        reminder={reminderToEdit}
      />
      
      <VoiceInput
        open={isVoiceInputOpen}
        onClose={() => setIsVoiceInputOpen(false)}
      />
      
      <AlertDialog open={reminderToDelete !== null} onOpenChange={(open) => !open && setReminderToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Reminder</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this reminder? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

interface ReminderItemProps {
  reminder: Reminder;
  onToggle: (id: string) => Promise<void>;
  onEdit: (reminder: Reminder) => void;
  onDelete: (reminder: Reminder) => void;
}

const ReminderItem: React.FC<ReminderItemProps> = ({ reminder, onToggle, onEdit, onDelete }) => {
  const reminderDate = new Date(reminder.datetime);
  const isOverdue = !reminder.completed && reminderDate < new Date();
  
  // Format the date nicely
  const formatDate = () => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const reminderDay = new Date(
      reminderDate.getFullYear(), 
      reminderDate.getMonth(), 
      reminderDate.getDate()
    );
    
    if (reminderDay.getTime() === today.getTime()) {
      return `Today at ${reminderDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else if (reminderDay.getTime() === tomorrow.getTime()) {
      return `Tomorrow at ${reminderDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else {
      return reminderDate.toLocaleString([], { 
        weekday: 'short',
        month: 'short', 
        day: 'numeric',
        hour: '2-digit', 
        minute: '2-digit'
      });
    }
  };

  return (
    <Card className={`${reminder.completed ? 'bg-muted/40' : ''}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <Checkbox
            checked={reminder.completed}
            onCheckedChange={() => onToggle(reminder.id)}
            className={`mt-1 ${isOverdue ? 'text-destructive border-destructive' : ''}`}
          />
          
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h3 className={`font-medium ${reminder.completed ? 'text-muted-foreground line-through' : ''}`}>
                {reminder.title}
              </h3>
              <div className="flex items-center gap-2">
                {!reminder.completed && (
                  <>
                    <Button variant="ghost" size="icon" onClick={() => onEdit(reminder)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => onDelete(reminder)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </>
                )}
              </div>
            </div>
            
            <p className="text-sm text-muted-foreground">
              {formatDate()}
            </p>
            
            {isOverdue && (
              <Badge variant="destructive" className="mt-1">Overdue</Badge>
            )}
            
            {reminder.soundName && (
              <div className="flex items-center gap-1 mt-1">
                <Badge variant="outline" className="text-xs">
                  Sound: {reminder.soundName}
                </Badge>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RemindersScreen;
