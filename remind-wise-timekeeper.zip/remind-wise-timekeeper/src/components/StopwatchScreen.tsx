
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { useStopwatch } from '@/contexts/StopwatchContext';

const StopwatchScreen = () => {
  const { time, isRunning, start, pause, reset } = useStopwatch();

  // Format the time (HH:MM:SS.ms)
  const formatTime = () => {
    const totalMs = time;
    const ms = totalMs % 1000;
    const totalSeconds = Math.floor(totalMs / 1000);
    const seconds = totalSeconds % 60;
    const totalMinutes = Math.floor(totalSeconds / 60);
    const minutes = totalMinutes % 60;
    const hours = Math.floor(totalMinutes / 60);

    const pad = (num: number, size: number) => {
      let numStr = num.toString();
      while (numStr.length < size) numStr = '0' + numStr;
      return numStr;
    };

    return `${pad(hours, 2)}:${pad(minutes, 2)}:${pad(seconds, 2)}.${pad(Math.floor(ms / 10), 2)}`;
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center p-4">
        <h1 className="text-2xl font-bold text-stopwatch">Stopwatch</h1>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md stopwatch-gradient-bg text-white shadow-lg">
          <CardContent className="flex flex-col items-center justify-center p-8">
            <div className="text-5xl font-mono font-bold my-8">
              {formatTime()}
            </div>
          </CardContent>
        </Card>

        <div className="flex items-center justify-center gap-4 mt-8">
          {isRunning ? (
            <Button
              onClick={pause}
              variant="outline"
              size="lg"
              className="rounded-full h-16 w-16"
            >
              <Pause className="h-8 w-8" />
            </Button>
          ) : (
            <Button
              onClick={start}
              variant="default"
              size="lg"
              className="rounded-full h-16 w-16 bg-stopwatch hover:bg-stopwatch-dark"
            >
              <Play className="h-8 w-8" />
            </Button>
          )}

          <Button
            onClick={reset}
            variant="outline"
            size="lg"
            className="rounded-full h-16 w-16"
            disabled={time === 0}
          >
            <RotateCcw className="h-8 w-8" />
          </Button>
        </div>

        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>Stopwatch will continue running in the background</p>
        </div>
      </div>
    </div>
  );
};

export default StopwatchScreen;
