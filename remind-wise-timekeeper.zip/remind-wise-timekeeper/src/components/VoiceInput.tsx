
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Mic, Square } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useReminders } from '@/contexts/ReminderContext';
import { parseDateTime } from '@/services/dateTimeParser';
import { startVoiceRecognition, stopVoiceRecognition, subscribeToVoiceResults } from '@/services/voiceService';

interface VoiceInputProps {
  open: boolean;
  onClose: () => void;
}

const VoiceInput: React.FC<VoiceInputProps> = ({ open, onClose }) => {
  const [isRecognizing, setIsRecognizing] = useState(false);
  const [voiceText, setVoiceText] = useState('');
  const [processing, setProcessing] = useState(false);
  const { toast } = useToast();
  const { addReminder } = useReminders();
  
  useEffect(() => {
    if (open) {
      // Reset state when dialog opens
      setVoiceText('');
      setIsRecognizing(false);
      setProcessing(false);
    }
  }, [open]);
  
  useEffect(() => {
    // Subscribe to voice recognition results
    const unsubscribe = subscribeToVoiceResults('voice-input-dialog', (result) => {
      setIsRecognizing(result.isRecognizing);
      
      if (result.results && result.results.length > 0) {
        setVoiceText(result.results[0]);
      }
      
      if (result.error) {
        toast({
          variant: "destructive",
          title: "Voice recognition failed",
          description: result.error.message,
        });
      }
    });
    
    return () => unsubscribe();
  }, [toast]);
  
  // Process the voice input when we get a result
  useEffect(() => {
    const processVoiceInput = async () => {
      if (voiceText && !isRecognizing) {
        setProcessing(true);
        
        try {
          // Use the natural language parser to extract date and time
          const parsedDateTime = await parseDateTime(voiceText);
          
          if (parsedDateTime) {
            // Extract the title (text without the time part)
            // This is simplified - in a real app we'd use the NLP results
            // to extract the title more accurately
            let title = voiceText;
            
            // Create the reminder
            await addReminder({
              title,
              datetime: parsedDateTime.toISOString(),
            });
            
            toast({
              title: "Reminder created",
              description: `${title} for ${parsedDateTime.toLocaleString()}`,
            });
            
            onClose();
          } else {
            toast({
              variant: "destructive",
              title: "Couldn't parse date/time",
              description: "Please try again with a clearer time reference",
            });
          }
        } catch (error) {
          console.error('Error processing voice input:', error);
          toast({
            variant: "destructive",
            title: "Processing failed",
            description: "Please try again",
          });
        } finally {
          setProcessing(false);
        }
      }
    };
    
    processVoiceInput();
  }, [voiceText, isRecognizing, addReminder, onClose, toast]);
  
  const handleStartRecording = async () => {
    try {
      await startVoiceRecognition();
    } catch (error) {
      console.error('Error starting voice recognition:', error);
      toast({
        variant: "destructive",
        title: "Couldn't access microphone",
        description: "Please check your permissions and try again",
      });
    }
  };
  
  const handleStopRecording = async () => {
    try {
      await stopVoiceRecognition();
    } catch (error) {
      console.error('Error stopping voice recognition:', error);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <div className="flex flex-col items-center justify-center py-8 space-y-6">
          <div className="text-center">
            <h2 className="text-xl font-semibold mb-2">Voice Reminder</h2>
            <p className="text-muted-foreground">
              {isRecognizing 
                ? "Listening..." 
                : processing 
                ? "Processing..." 
                : "Speak to create a reminder"}
            </p>
          </div>
          
          {voiceText && !isRecognizing && (
            <div className="bg-muted p-4 rounded-md w-full text-center">
              <p>{voiceText}</p>
            </div>
          )}
          
          <div className="flex items-center justify-center">
            {isRecognizing ? (
              <Button 
                onClick={handleStopRecording} 
                variant="destructive" 
                size="lg" 
                className="rounded-full h-16 w-16 flex items-center justify-center"
              >
                <Square className="h-6 w-6" />
              </Button>
            ) : (
              <Button 
                onClick={handleStartRecording} 
                variant="default" 
                size="lg" 
                className={`rounded-full h-16 w-16 flex items-center justify-center bg-reminder hover:bg-reminder-dark ${isRecognizing ? 'animate-pulse-recording' : ''}`}
                disabled={processing}
              >
                <Mic className="h-6 w-6" />
              </Button>
            )}
          </div>
          
          <div className="text-center text-sm text-muted-foreground">
            {isRecognizing ? (
              <p>Tap to stop recording</p>
            ) : processing ? (
              <p>Processing your reminder...</p>
            ) : (
              <p>Try saying "Meeting tomorrow at 3pm"</p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VoiceInput;
