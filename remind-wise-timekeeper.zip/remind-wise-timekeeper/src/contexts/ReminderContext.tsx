
import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from '@/components/ui/use-toast';

export type Reminder = {
  id: string;
  title: string;
  datetime: string;
  completed: boolean;
  notificationId?: string;
  soundName?: string;
};

type ReminderContextType = {
  reminders: Reminder[];
  addReminder: (reminder: Omit<Reminder, 'id' | 'completed'>) => Promise<Reminder>;
  updateReminder: (reminder: Reminder) => Promise<void>;
  deleteReminder: (id: string) => Promise<void>;
  toggleCompleted: (id: string) => Promise<void>;
  loading: boolean;
};

const ReminderContext = createContext<ReminderContextType | undefined>(undefined);

export const useReminders = () => {
  const context = useContext(ReminderContext);
  if (context === undefined) {
    throw new Error('useReminders must be used within a ReminderProvider');
  }
  return context;
};

// Mock AsyncStorage for web preview
const mockAsyncStorage = {
  getItem: async (key: string) => {
    const item = localStorage.getItem(key);
    return item;
  },
  setItem: async (key: string, value: string) => {
    localStorage.setItem(key, value);
  },
};

export const ReminderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const loadReminders = async () => {
      try {
        setLoading(true);
        const storedReminders = await mockAsyncStorage.getItem('reminders');
        if (storedReminders) {
          setReminders(JSON.parse(storedReminders));
        }
      } catch (error) {
        console.error('Failed to load reminders:', error);
        toast({
          variant: "destructive",
          title: "Failed to load reminders",
          description: "Please try again later",
        });
      } finally {
        setLoading(false);
      }
    };

    loadReminders();
  }, []);

  const saveReminders = async (updatedReminders: Reminder[]) => {
    try {
      await mockAsyncStorage.setItem('reminders', JSON.stringify(updatedReminders));
    } catch (error) {
      console.error('Failed to save reminders:', error);
      toast({
        variant: "destructive",
        title: "Failed to save reminders",
        description: "Your changes may not be saved",
      });
    }
  };

  const addReminder = async (reminderData: Omit<Reminder, 'id' | 'completed'>): Promise<Reminder> => {
    const newReminder: Reminder = {
      ...reminderData,
      id: Date.now().toString(),
      completed: false,
    };

    const updatedReminders = [...reminders, newReminder];
    setReminders(updatedReminders);
    await saveReminders(updatedReminders);
    
    toast({
      title: "Reminder created",
      description: `${newReminder.title} for ${new Date(newReminder.datetime).toLocaleString()}`,
    });
    
    return newReminder;
  };

  const updateReminder = async (updatedReminder: Reminder) => {
    const updatedReminders = reminders.map(r => 
      r.id === updatedReminder.id ? updatedReminder : r
    );
    setReminders(updatedReminders);
    await saveReminders(updatedReminders);
    
    toast({
      title: "Reminder updated",
      description: updatedReminder.title,
    });
  };

  const deleteReminder = async (id: string) => {
    const updatedReminders = reminders.filter(r => r.id !== id);
    setReminders(updatedReminders);
    await saveReminders(updatedReminders);
    
    toast({
      title: "Reminder deleted",
      description: "The reminder has been removed",
    });
  };

  const toggleCompleted = async (id: string) => {
    const updatedReminders = reminders.map(r => 
      r.id === id ? { ...r, completed: !r.completed } : r
    );
    setReminders(updatedReminders);
    await saveReminders(updatedReminders);
  };

  return (
    <ReminderContext.Provider value={{ 
      reminders, 
      addReminder, 
      updateReminder, 
      deleteReminder, 
      toggleCompleted, 
      loading 
    }}>
      {children}
    </ReminderContext.Provider>
  );
};
