
import React, { createContext, useContext, useState, useEffect, useRef } from 'react';

type StopwatchContextType = {
  time: number;
  isRunning: boolean;
  start: () => void;
  pause: () => void;
  reset: () => void;
};

const StopwatchContext = createContext<StopwatchContextType | undefined>(undefined);

export const useStopwatch = () => {
  const context = useContext(StopwatchContext);
  if (context === undefined) {
    throw new Error('useStopwatch must be used within a StopwatchProvider');
  }
  return context;
};

// Mock AsyncStorage for web preview
const mockAsyncStorage = {
  getItem: async (key: string) => {
    const item = localStorage.getItem(key);
    return item;
  },
  setItem: async (key: string, value: string) => {
    localStorage.setItem(key, value);
  },
};

export const StopwatchProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [time, setTime] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const intervalRef = useRef<number | null>(null);

  // Load saved time on startup
  useEffect(() => {
    const loadSavedTime = async () => {
      try {
        const savedState = await mockAsyncStorage.getItem('stopwatchState');
        if (savedState) {
          const { time: savedTime, lastUpdated, isRunning: wasRunning } = JSON.parse(savedState);
          
          if (wasRunning) {
            // If it was running when the app was closed, add elapsed time
            const elapsedSinceLastUpdate = Date.now() - lastUpdated;
            setTime(savedTime + elapsedSinceLastUpdate);
            setIsRunning(true);
          } else {
            setTime(savedTime);
          }
        }
      } catch (error) {
        console.error('Failed to load stopwatch state:', error);
      }
    };

    loadSavedTime();
  }, []);

  // Save time when it changes or app state changes
  useEffect(() => {
    const saveState = async () => {
      try {
        await mockAsyncStorage.setItem('stopwatchState', JSON.stringify({
          time,
          lastUpdated: Date.now(),
          isRunning,
        }));
      } catch (error) {
        console.error('Failed to save stopwatch state:', error);
      }
    };

    saveState();
  }, [time, isRunning]);

  // Tick the stopwatch
  useEffect(() => {
    if (isRunning) {
      intervalRef.current = window.setInterval(() => {
        setTime(prevTime => prevTime + 10);
      }, 10);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning]);

  const start = () => {
    setIsRunning(true);
  };

  const pause = () => {
    setIsRunning(false);
  };

  const reset = () => {
    setIsRunning(false);
    setTime(0);
  };

  return (
    <StopwatchContext.Provider value={{ time, isRunning, start, pause, reset }}>
      {children}
    </StopwatchContext.Provider>
  );
};
