
import React, { useState, useEffect } from 'react';
import { ReminderProvider } from '@/contexts/ReminderContext';
import { StopwatchProvider } from '@/contexts/StopwatchContext';
import RemindersScreen from '@/components/RemindersScreen';
import StopwatchScreen from '@/components/StopwatchScreen';
import Navigation from '@/components/Navigation';
import { scheduleDailySummaryNotification } from '@/services/notificationService';
import { useReminders } from '@/contexts/ReminderContext';

// This component handles the daily summary notification
const DailySummaryHandler = () => {
  const { reminders } = useReminders();
  
  useEffect(() => {
    // Schedule the daily summary notification when reminders change
    scheduleDailySummaryNotification(reminders);
  }, [reminders]);
  
  return null;
};

const Index = () => {
  const [activeTab, setActiveTab] = useState<'reminders' | 'stopwatch'>('reminders');

  return (
    <div className="min-h-screen bg-background">
      <ReminderProvider>
        <StopwatchProvider>
          {/* Main content */}
          <div className="pb-16"> {/* Add padding to accommodate bottom navigation */}
            {activeTab === 'reminders' && <RemindersScreen />}
            {activeTab === 'stopwatch' && <StopwatchScreen />}
          </div>
          
          {/* Navigation */}
          <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
          
          {/* Daily summary handler */}
          <DailySummaryHandler />
        </StopwatchProvider>
      </ReminderProvider>
    </div>
  );
};

export default Index;
