
// This is a mock service that simulates parsing natural language dates
// In a real React Native app, we'd use a backend with chrono-node

export const parseDateTime = async (text: string): Promise<Date | null> => {
  // Simple patterns for demo purposes
  const patterns = [
    {
      regex: /tomorrow at (\d+)(?::(\d+))?\s*(am|pm)?/i,
      parse: (match: RegExpMatchArray) => {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        let hours = parseInt(match[1], 10);
        const minutes = match[2] ? parseInt(match[2], 10) : 0;
        const ampm = match[3]?.toLowerCase();
        
        if (ampm === 'pm' && hours < 12) hours += 12;
        if (ampm === 'am' && hours === 12) hours = 0;
        
        tomorrow.setHours(hours, minutes, 0, 0);
        return tomorrow;
      }
    },
    {
      regex: /today at (\d+)(?::(\d+))?\s*(am|pm)?/i,
      parse: (match: RegExpMatchArray) => {
        const today = new Date();
        
        let hours = parseInt(match[1], 10);
        const minutes = match[2] ? parseInt(match[2], 10) : 0;
        const ampm = match[3]?.toLowerCase();
        
        if (ampm === 'pm' && hours < 12) hours += 12;
        if (ampm === 'am' && hours === 12) hours = 0;
        
        today.setHours(hours, minutes, 0, 0);
        return today;
      }
    },
    {
      regex: /next (\w+) at (\d+)(?::(\d+))?\s*(am|pm)?/i,
      parse: (match: RegExpMatchArray) => {
        const days = {
          'monday': 1, 'tuesday': 2, 'wednesday': 3, 'thursday': 4,
          'friday': 5, 'saturday': 6, 'sunday': 0
        };
        
        const targetDay = days[match[1].toLowerCase() as keyof typeof days];
        const today = new Date();
        const currentDay = today.getDay();
        
        let daysToAdd = targetDay - currentDay;
        if (daysToAdd <= 0) daysToAdd += 7;
        
        const targetDate = new Date();
        targetDate.setDate(today.getDate() + daysToAdd);
        
        let hours = parseInt(match[2], 10);
        const minutes = match[3] ? parseInt(match[3], 10) : 0;
        const ampm = match[4]?.toLowerCase();
        
        if (ampm === 'pm' && hours < 12) hours += 12;
        if (ampm === 'am' && hours === 12) hours = 0;
        
        targetDate.setHours(hours, minutes, 0, 0);
        return targetDate;
      }
    },
    {
      regex: /in (\d+) (minute|minutes|hour|hours|day|days)/i,
      parse: (match: RegExpMatchArray) => {
        const amount = parseInt(match[1], 10);
        const unit = match[2].toLowerCase();
        
        const now = new Date();
        
        if (unit === 'minute' || unit === 'minutes') {
          now.setMinutes(now.getMinutes() + amount);
        } else if (unit === 'hour' || unit === 'hours') {
          now.setHours(now.getHours() + amount);
        } else if (unit === 'day' || unit === 'days') {
          now.setDate(now.getDate() + amount);
        }
        
        return now;
      }
    }
  ];

  // Try each pattern
  for (const pattern of patterns) {
    const match = text.match(pattern.regex);
    if (match) {
      try {
        return pattern.parse(match);
      } catch (e) {
        console.error('Error parsing date:', e);
        continue;
      }
    }
  }

  // Fallback to 30 minutes from now if no pattern matches
  const fallbackDate = new Date();
  fallbackDate.setMinutes(fallbackDate.getMinutes() + 30);
  return fallbackDate;
};
