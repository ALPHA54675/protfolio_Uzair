
import { toast } from '@/components/ui/use-toast';
import { Reminder } from '@/contexts/ReminderContext';

// This is a mock service for web preview
// In a real React Native app, we'd use expo-notifications

export const scheduleNotification = async (reminder: Reminder): Promise<string> => {
  console.log(`Scheduling notification for: ${reminder.title} at ${reminder.datetime}`);
  
  const notificationId = `notification-${Date.now()}`;
  
  // Calculate time until the notification
  const now = new Date();
  const reminderDate = new Date(reminder.datetime);
  const timeUntilNotification = reminderDate.getTime() - now.getTime();
  
  if (timeUntilNotification > 0) {
    // Schedule a toast notification for demo purposes
    setTimeout(() => {
      toast({
        title: reminder.title,
        description: `Time: ${reminderDate.toLocaleTimeString()}`,
      });
    }, timeUntilNotification);
  }
  
  return notificationId;
};

export const cancelNotification = async (notificationId?: string) => {
  if (notificationId) {
    console.log(`Cancelling notification: ${notificationId}`);
    // In a real app, we would cancel the actual notification here
  }
};

export const getAvailableNotificationSounds = async () => {
  // Mock list of sounds
  return [
    { id: 'default', name: 'Default' },
    { id: 'bell', name: 'Bell' },
    { id: 'chime', name: 'Chime' },
    { id: 'electronic', name: 'Electronic' },
    { id: 'marimba', name: 'Marimba' },
  ];
};

export const scheduleDailySummaryNotification = async (reminders: Reminder[]) => {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(8, 0, 0, 0); // 8 AM tomorrow
  
  const todayReminders = reminders.filter(r => {
    const reminderDate = new Date(r.datetime);
    const today = new Date();
    return (
      reminderDate.getDate() === today.getDate() &&
      reminderDate.getMonth() === today.getMonth() &&
      reminderDate.getFullYear() === today.getFullYear() &&
      !r.completed
    );
  });
  
  if (todayReminders.length > 0) {
    console.log(`Scheduled daily summary for ${todayReminders.length} reminders`);
  }
  
  // In a real app, we would schedule a persistent notification here
  return 'daily-summary-notification';
};
