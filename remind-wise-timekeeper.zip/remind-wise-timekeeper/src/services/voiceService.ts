
import { toast } from '@/components/ui/use-toast';

// This is a mock service for web preview
// In a real React Native app, we'd use @react-native-voice/voice

export type VoiceResult = {
  results?: string[];
  isRecognizing: boolean;
  error?: Error;
};

let mockRecognitionTimeout: ReturnType<typeof setTimeout> | null = null;
let recognitionCallbacks: { [key: string]: (result: VoiceResult) => void } = {};

export const startVoiceRecognition = (): Promise<void> => {
  const mockResults = [
    "Buy groceries tomorrow at 5pm",
    "Call mom today at 3pm",
    "Meeting with team next Monday at 10am",
    "Take medicine in 30 minutes",
    "Submit report in 2 hours",
    "Dentist appointment next Tuesday at 2pm",
    "Water the plants tomorrow morning at 8am",
    "Pay electricity bill in 2 days",
  ];
  
  const randomResult = mockResults[Math.floor(Math.random() * mockResults.length)];
  
  // Simulate recognition delay
  if (mockRecognitionTimeout) {
    clearTimeout(mockRecognitionTimeout);
  }
  
  // Notify listeners that recognition has started
  Object.values(recognitionCallbacks).forEach(callback => {
    callback({
      isRecognizing: true
    });
  });
  
  return new Promise((resolve) => {
    mockRecognitionTimeout = setTimeout(() => {
      // Notify listeners of the result
      Object.values(recognitionCallbacks).forEach(callback => {
        callback({
          results: [randomResult],
          isRecognizing: false
        });
      });
      
      resolve();
    }, 2000); // Simulate 2 second recognition time
  });
};

export const stopVoiceRecognition = (): Promise<void> => {
  if (mockRecognitionTimeout) {
    clearTimeout(mockRecognitionTimeout);
    mockRecognitionTimeout = null;
  }
  
  // Notify listeners that recognition has stopped
  Object.values(recognitionCallbacks).forEach(callback => {
    callback({
      isRecognizing: false
    });
  });
  
  return Promise.resolve();
};

export const subscribeToVoiceResults = (
  id: string, 
  callback: (result: VoiceResult) => void
): () => void => {
  recognitionCallbacks[id] = callback;
  
  // Return unsubscribe function
  return () => {
    delete recognitionCallbacks[id];
  };
};

export const isVoiceAvailable = (): Promise<boolean> => {
  return Promise.resolve(true); // Always available in our mock
};
